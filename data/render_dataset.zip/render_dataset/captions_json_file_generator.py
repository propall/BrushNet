#!/usr/bin/env python
"""
Generate a captions.json file from images in a folder.
Creates a JSON file with image filenames as keys and empty strings as values
for manual caption entry.
"""

import os
import json
import glob
import re

def natural_sort_key(text):
    """
    Convert a string into a list of string and number chunks for natural sorting.
    "img10.jpg" becomes ["img", 10, ".jpg"]
    """
    def tryint(s):
        try:
            return int(s)
        except ValueError:
            return s
    
    return [tryint(c) for c in re.split(r'(\d+)', text)]

def generate_captions_json(images_folder, output_file="captions.json"):
    """
    Generate a captions.json file from all images in a folder.
    
    Args:
        images_folder (str): Path to the folder containing images
        output_file (str): Name of the output JSON file
    """
    
    # Supported image formats
    image_extensions = ['*.jpg', '*.jpeg', '*.png']
    
    # Find all image files
    image_files = []
    for extension in image_extensions:
        pattern = os.path.join(images_folder, extension)
        image_files.extend(glob.glob(pattern))
        
        # Also check uppercase versions
        pattern_upper = os.path.join(images_folder, extension.upper())
        image_files.extend(glob.glob(pattern_upper))
    
    # Extract just the filenames (not full paths)
    image_filenames = [os.path.basename(img) for img in image_files]
    
    # Sort using natural sorting (handles numbers properly)
    image_filenames.sort(key=natural_sort_key)
    
    # Create dictionary with empty string values
    captions_dict = {filename: "" for filename in image_filenames}
    
    # Write to JSON file
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(captions_dict, f, indent=2, ensure_ascii=False)
    
    print(f"Generated {output_file} with {len(image_filenames)} image entries")
    print(f"Found images: {image_filenames[:5]}..." if len(image_filenames) > 5 else f"Found images: {image_filenames}")
    print(f"\nYou can now edit {output_file} to add your captions manually.")
    
    return captions_dict

def preview_json_structure(captions_dict, num_examples=3):
    """Preview the structure of the generated JSON."""
    print(f"\nPreview of {output_file} structure:")
    print("-" * 40)
    
    items = list(captions_dict.items())
    for i, (filename, caption) in enumerate(items[:num_examples]):
        print(f'  "{filename}": "{caption}",')
    
    if len(items) > num_examples:
        print(f"  ... ({len(items) - num_examples} more entries)")
    
    print("-" * 40)

def validate_images_folder(images_folder):
    """Validate that the images folder exists and contains images."""
    if not os.path.exists(images_folder):
        print(f"Error: Folder '{images_folder}' does not exist!")
        return False
    
    if not os.path.isdir(images_folder):
        print(f"Error: '{images_folder}' is not a directory!")
        return False
    
    # Check for any image files
    image_extensions = ['*.jpg', '*.jpeg', '*.png']
    has_images = False
    
    for extension in image_extensions:
        pattern = os.path.join(images_folder, extension)
        if glob.glob(pattern):
            has_images = True
            break
        
        # Check uppercase
        pattern_upper = os.path.join(images_folder, extension.upper())
        if glob.glob(pattern_upper):
            has_images = True
            break
    
    if not has_images:
        print(f"Warning: No image files found in '{images_folder}'")
        print("Supported formats: jpg, jpeg, png")
        return False
    
    return True

if __name__ == "__main__":
    # Configuration
    images_folder = "./images"  # Change this to your images folder path
    output_file = "captions.json"
    
    print("Caption JSON Generator")
    print("=" * 40)
    
    # Validate input folder
    if not validate_images_folder(images_folder):
        print("\nPlease update the 'images_folder' variable to point to your images directory.")
        exit(1)
    
    # Generate the captions JSON
    captions_dict = generate_captions_json(images_folder, output_file)
    
    # Show preview
    preview_json_structure(captions_dict)
    
    print(f"\n✓ Successfully created {output_file}")
    print(f"✓ Ready for manual caption entry")
    
    # Provide example of what to fill in
    print(f"\nExample caption entries (remember to describe existing floor types):")
    print('  "image_001.jpg": "light oak hardwood flooring",')
    print('  "image_002.png": "gray ceramic tile floor",')
    print('  "image_003.jpg": "beige carpet with low pile",')